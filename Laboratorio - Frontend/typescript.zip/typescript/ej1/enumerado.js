var Clases;
(function (Clases) {
    var Tipo;
    (function (Tipo) {
        Tipo[Tipo["Ave"] = 0] = "Ave";
        Tipo[Tipo["Perro"] = 1] = "Perro";
        Tipo[Tipo["Gato"] = 2] = "Gato";
        Tipo[Tipo["Reptil"] = 3] = "Reptil";
        Tipo[Tipo["Pez"] = 4] = "Pez";
    })(Tipo = Clases.Tipo || (Clases.Tipo = {}));
})(Clases || (Clases = {}));
//# sourceMappingURL=enumerado.js.map