namespace Clases{
    export enum Tipo{
    Ave,
    Perro,
    Gato,
    Reptil,
    Pez
}
}

