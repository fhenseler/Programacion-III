//archivo de definicones para poder usar jquery con typescript
//npm install --save-dev @types/jquery

$(document).ready(function(){
    $("#miH1").text("Nos vamos al recreo");
});